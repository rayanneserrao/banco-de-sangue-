package br.com.wktechnology.banco_de_sangue

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
