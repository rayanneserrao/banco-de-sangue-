final class Font {
  static const double xxs = 11.0;
  static const double xs = 13.0;
  static const double sm = 15.0;
  static const double md = 17.0;
  static const double lg = 19.0;
}
