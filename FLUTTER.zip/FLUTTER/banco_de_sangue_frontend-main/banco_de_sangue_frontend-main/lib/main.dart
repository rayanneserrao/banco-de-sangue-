import 'package:banco_de_sangue/src/app_widget.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const AppWidget());
}
