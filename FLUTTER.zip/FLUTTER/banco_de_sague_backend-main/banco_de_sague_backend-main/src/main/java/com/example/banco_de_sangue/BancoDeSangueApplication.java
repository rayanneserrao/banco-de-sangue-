package com.example.banco_de_sangue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BancoDeSangueApplication {

	public static void main(String[] args) {
		SpringApplication.run(BancoDeSangueApplication.class, args);
	}

}
