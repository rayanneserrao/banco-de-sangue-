package com.example.banco_de_sangue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BancoDeSangueApplicationTests {

	@Test
	void contextLoads() {
	}

}
